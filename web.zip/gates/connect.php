<?php

	//LOCALHOST
	// $host =  "localhost";
	// $user = "root";
	// $passwd = "";
	// $dbname = "medpmkk";
	// $charset =  "utf8";

	//LOCALHOST
	$host =  "localhost";
	$user = "medpmkcourse";
	$passwd = "ducklab1701944";
	$dbname = "medpmkcourse";
	$charset =  "utf8";



	$conn = mysqli_connect($host, $user, $passwd ,$dbname);

	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	mysqli_set_charset($conn,"utf8");

 
?>
