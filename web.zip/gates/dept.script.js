/////////////////////////////////////////////////////////////////////////////////////
////////////////////           dept Script          ///////////////////////////
var dept = {
				url : '../gates/dept.inc.php'
			};
 
//////////////////////////////////////////////////////////////////////////////////////////////////
dept.LoadCharOfDisease=function(){
	var setData = {};
	$.ajax({
		url:dept.url+'?mode=LoadCharOfDisease',
		type:'POST',
		dataType:'json',
		data: setData , 
		success:function(data){
			console.log(data);  
			 
			var cont = '' ; 
			$.each( data['char_th'] , function( key1, value1 ) {  
				
			}); 
		//	$(".box_disease_list").html(cont); 
		},
		error:function(data){
			console.log(data);
			console.log('check dept.LoadCharOfDisease');
			duck.NotiDanger();
		}
	});
};

dept.LoadDiseaseAllByStep=function(){
	
	var setData = {};

	$.ajax({
		url:dept.url+'?mode=LoadDiseaseAllByStep',
		type:'POST',
		dataType:'json',
		data: setData , 
		success:function(data){
			console.log(data);  
			 
			var cont = '' ; 

			$.each( data['char_th'] , function( key1, value1 ) {  

				$.each( value1 , function( key2, value2 ) {  
					cont += '<p class="disease_list">'+key2+'</p>' ; 
					cont += '<div class="disease_list_box">' ;  
					$.each( value2 , function( key3, value3 ) {  
						cont += '<a class="disease_listsub"  href="disease_detail.php?d'+value3['id']+'" ><i class="fa fa-circle-o disease_listsub_icon" ></i>\
									'+value3['disease_name_th']+ '\
								</a>' ;
					});
					cont += '</div>' ; 
				});
			}); 

			$(".box_disease_list").html(cont); 

		},
		error:function(data){
			console.log(data);
			console.log('check dept.LoadDiseaseByStep');
			duck.NotiDanger();
		}
	});

};

dept.LoadDiseaseByTitleName=function(titlename,langtype){
	 //var txt = "disease_name_"+localStorage.langcode ;
	 
	if(langtype=="en"){
		var setData = {
			table : "disease" , 
			where : {  
				enable: "Y" ,
				deleted: 0 ,
			},
			wherelike : {  
				disease_name_en : titlename
			}, 
			orderby: "   disease_name_en  ASC " ,
			limit : "" , 
		};
	
	}else{
		
		var setData = {
			table : "disease" , 
			where : {  
				enable: "Y" ,
				deleted: 0 ,
			},
			wherelike : {  
				disease_name_th : titlename
			}, 
			orderby: " CONVERT (   disease_name_th  USING tis620 ) ASC " ,
			limit : "" , 
		};
	} 
 
	

	console.log(setData);

	$.ajax({
		url:dept.url+'?mode=LoadLikeTitle',
		type:'POST',
		dataType:'json',
		data: setData , 
		success:function(data){
			console.log(data); 
			 
			var cont = '' ; 
			cont += '<p class="disease_list">'+titlename+'</p>' ; 
			cont += '<div class="disease_list_box">' ;  
			$.each( data , function( key, value ) { 
				// cont += '<a class="disease_listsub"  href="javascript:dept.OpenDiseaseDetail(\''+value['id']+'\'\)" ><i class="fa fa-circle-o disease_listsub_icon" ></i>\
				// 			'+value['disease_name_'+langtype]+ '\
				// 		</a>' ;
				cont += '<a class="disease_listsub"  href="disease_detail.php?d='+value['id']+'" ><i class="fa fa-circle-o disease_listsub_icon" ></i>\
							'+value['disease_name_'+langtype]+ '\
						</a>' ;
			});
			cont += '</div>' ; 


			$(".box_disease_list").html(cont);
			

		},
		error:function(data){
			console.log(data);
			console.log('check dept.LoadDiseaseByTitleName');
			duck.NotiDanger();
		}
	});

};

dept.LoadDiseaseHeader=function(disease_id=1){
	
	 var mydata  = {
		table : "disease_header",
		where : {

		},
		orderby : " orderby DESC ",
		limit : ""
	 };
	console.log(mydata)
	$.ajax({
			url:dept.url+'?mode=LoadAllData',
			type:'POST',
			dataType:'json',
			data: mydata ,
			success:function(data){
					// alert('OK');


					//#blockbtn

			    console.log(data); 
					var dept ="" ;
					// var x = 0 ;
					data.map((item) =>{ 
						// alert(disease_id)
						dept += ' <a class="tab_menu" href="javascript:dept.LoadDiseaseDetail(\''+disease_id+'\'\ , \''+item.id+'\'\)">'+item.disease_header_th+'</a>' ;
						// <button class="btn btn-block btn-info btn1 btn_diseasedetail" onclick="contents.LoadDiseaseDetail(\''+disease_id+'\'\ , \''+item.id+'\'\);">  '+item.disease_header_th +' </button>' 

				});

					$("#blockbtn").html(dept); // แสดงผล html 

		   },error:function(data){
				// alert('NOT OK');
		    console.log(data);
		    duck.NotiDanger();
		   }
	});
};

dept.LoadDiseaseDetail=function(disease_id,disease_header_id){
	// $table = $_POST['table'];
	// $where = $_POST['where'];
	// $orderby = $_POST['orderby'];
	// $limit = $_POST['limit'];
		//alert(disease_id)
	 var detail  = {
		table : "disease_detail",
		where : {
			disease_id : disease_id ,
			disease_header_id : disease_header_id , 
			enable : "Y",
			deleted : 0 
		},
		orderby : " orderby DESC ",
		limit : "" ,
		fieldcontent : "detail_th" 
	 };
	console.log(detail)
	$.ajax({
			url:dept.url+'?mode=LoadAllData',
			type:'POST',
			dataType:'json',
			data: detail ,
			success:function(data){
				//alert('LoadDiseaseDetail');
				console.log(data); 
				
				var txt =	$.parseHTML(data[0].detail_th );
					$("#block_disease_detail").html(txt);


		   },error:function(data){
				alert('NOT OK');
		    console.log(data);
		    duck.NotiDanger();
		   }
	});
};




dept.OpenDiseaseDetail=function(disease_id){
	// console.log(" dept.OpenDiseaseDetail : "+disease_id);

};

dept.LoadNewsmass=function(contents_type_code,contents_type,num){
	
	console.log(contents_type_code);


	var langcode = localStorage.langcode ; 
	var tablename = "";
	if(contents_type=="news"){
		tablename = 'news_mapping';
	}else{
		tablename = 'auction_mapping';
	}

	if(langcode=="th"){
		var setData = {
			table : tablename,
			where : { 
				enable_th : "Y",
				type : contents_type_code 
			},
			orderby : ' datetime  DESC ',
			limit : ' 0,5 '
		};
	}else{
		var setData = {
			table : tablename,
			where : { 
				enable_en : "Y",
				type : contents_type_code 
			},
			orderby : ' datetime  DESC ',
			limit : ' 0,5 '
		};
	}
	

	console.log(setData);


	var setactivesub = "fade";
	if(num==0){ 
		setactivesub ="active" ;
	}


	var cnt = 0 ;
	var content_lisub = '<div id="'+contents_type_code+'" class="container tab-pane mt-4   '+setactivesub+'">';  
	$("#news_main_home").append(content_lisub);



	$.ajax({
		url:contents.url+'?mode=LoadHomeNewsAuction',
		type:'POST',
		dataType:'json',
		data: setData , 
		beforeSend:function(){
		},
		success:function(result,status,xhr){

			console.log(result);

			
			if( result) {
				$.each( result , function( key1, value1 ) {
					
					var datenews = duck.ConvertDate(value1['datetime'],'full',langcode);
					//var deptname = contents.LoadDepartmentByCode(value1['office']);
					var content_lisub2 ="";
					content_lisub2 +='	<div class="row">\
											<div class="col-lg-12 mt-2">\
												<div class="card">\
													<div class="card-body">\
														<div class="row">\
															<div class="col-lg-11 col-sm-11">\
															<h5 class="card-title">\
															<a href="#">'+value1['title_'+langcode]+'</a>\
															</h5>\
															</div>\
														</div>\
														<div class="footer	-detail">\
															<div class="row">\
																<div class=" col-md-2   col-6 time ">\
																<i class="fa fa-calendar" aria-hidden="true"> </i> \
																<span class="ml-0">'+datenews+'</span>\
																</div>\
																<div class=" col-md-2   col-6 view">\
																<i class="fa fa-eye" aria-hidden="true"> </i> \
																<span class="ml-0">'+value1['views']+'  view</span>\
																</div>\
																<div class="col-md-8   col-12 text-right name-depart">\
																<span class="mr-2"> '+value1['department_name_'+langcode]+' </span>  \
																</div>\
															</div> \
														</div>  \
														<hr class="lines linehomenews">\
													</div>\
												</div>  \
											</div>\
										</div>' ;
					cnt++
					$('#'+contents_type_code).append(content_lisub2);
				});
		}
		else{
			
				content_lisub +='<div class="row">\
									<div class="col-lg-12 mt-4">\
										<div class="card">\
											<div class="card-body">\
												<div class="row">\
													<div class="col-lg-11 col-sm-11">\
													<h5 class="card-title"> </h5>\
													</div>\
												</div>\
												<div class="footer-detail">\
													<div class="row">\
													 </div> \
												</div>  \
												<hr class="lines">\
											</div>\
										</div>  \
									</div>\
								</div>' ;
				
		}


			content_lisub +='	 </div>'; 
			

		}
	});
		
};



//////////////////////////////////////////////////////////////////////////////////////////////////
$( document ).ready(function() {
 

});

////////////////////          END dept Script         ///////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
