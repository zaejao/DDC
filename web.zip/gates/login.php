<?php
	include "connect.php";
	include "func.php";

	////////////////////////////////////////////////////////////

	//$position 	 =  $_POST['position'];

	$username 	 =  $_POST['username'];

	//$password 	 =  ($_POST['password']);
	$password 	 =  md5($_POST['password']);

		$sql="
				SELECT s.*  , sp.positionname , m.positionname_mini AS mposition
				FROM `staff` s
				LEFT JOIN  staff_position sp ON ( sp.id = s.staff_position_id )
				LEFT JOIN  militaryrank2 m ON ( m.id = s.militaryrank_id )
				WHERE
						s.email = '".$username. "'
				AND s.password = '".$password."'
				AND s.deleted = '0'
				AND s.enable = 'Y'
			";
	//	$result['sql'] = $sql ;
	//	echo $sql ; 

		$myquery = mysqli_query($conn, $sql);
		$numr = mysqli_num_rows($myquery);
		while($row = mysqli_fetch_assoc($myquery) ) {
			$result[] = $row;
		}

		$result['found'] = $numr;


		if($numr>0){
			$result['position'] = '1';
			$result['status'] = 'FOUND';
			$data_json	=  json_encode($result);
		}else{

			////////////////////////////////////////////////////////////
			$sql="
					SELECT l.* , ap.positionname , ap.positionname_mini , m.positionname_mini AS mposition
					FROM `lecturer` l
					LEFT JOIN `academic_position` ap  ON (ap.id = l.academic_position_id)
					LEFT JOIN  militaryrank m ON ( m.id = l.militaryrank_id )
					WHERE
							l.email = '".$username. "' 
					AND l.password = '".$password."' 
					AND l.deleted = '0' 
					AND l.enable = 'Y' 
				";
			//	$result['sql'] = $sql ;

			$myquery = mysqli_query($conn, $sql);
			$numr = mysqli_num_rows($myquery);
			while($row = mysqli_fetch_assoc($myquery) ) {
				$result[] = $row;
			}

			$result['found'] = $numr;


			if($numr>0){
				$result['position'] = '2';
				$result['status'] = 'FOUND';
				$data_json	=  json_encode($result);
			}else{

				 
				////////////////////////////////////////////////////////////


				$sql="
					SELECT
						sp.* ,
						se.student_id  ,
						se.student_year ,
						se.collegeyear ,
						se.collegebatch  ,
						st.titlename ,
						st.titlename_mini

						FROM `student_profile` sp
						LEFT JOIN `student_education` se  ON (se.student_profile_id = sp.id)
						LEFT JOIN student_titlename  st ON ( st.id = sp.student_titlename_id )
						WHERE
							(	sp.email = '".$username. "' 	AND sp.password = '".$password."' ) 
							OR 
							(	se.student_id = '".$username. "' 	AND sp.password = '".$password."' ) 

						AND sp.deleted = '0' 
						AND sp.enable = 'Y' 
					";
				//	$result['sql'] = $sql ;

				$myquery = mysqli_query($conn, $sql);
				$numr = mysqli_num_rows($myquery);
				while($row = mysqli_fetch_assoc($myquery) ) {
					$result[] = $row;
				}

				$result['found'] = $numr;

				if($numr==1){
					$result['position'] = '3';
					$result['status'] = 'FOUND';
					$data_json	=  json_encode($result);
				}else{
					
					//////////////////////////////////////////////////////////// 
				 
					$sql="
						SELECT 
							sp.* , 
							se.student_id  , 
							se.student_year ,  
							se.collegeyear , 
							se.collegebatch  ,
							st.titlename ,
							st.titlename_mini 
							
							FROM `student_profile` sp 
							LEFT JOIN `student_education` se  ON (se.student_profile_id = sp.id) 
							LEFT JOIN student_titlename  st ON ( st.id = sp.student_titlename_id ) 
							WHERE 
							sp.email = '".$username. "'  
							AND sp.deleted = '0' 
							AND sp.enable = 'Y' 
						"; 
					 	$result['sql'] = $sql ;

					$myquery = mysqli_query($conn, $sql);
					$numr = mysqli_num_rows($myquery);
					while($row = mysqli_fetch_assoc($myquery) ) {
						$result[] = $row;
					}

					$result['found'] = $numr;
					
					if($numr>0){
						$result['position'] = '3';
						$result['status'] = 'FOUND';
						$ptoken = '3'.md5($result[0]['id'].DateNowS()) ; 
						$result['ptoken'] = $ptoken ; 
						$sqlupdate = "UPDATE student_profile SET `password_token` = '".$ptoken."' WHERE id= '".$result[0]['id']."' " ; 
						
						$data_json	=  json_encode($result);
					}else{
						//////////////////////////////////////////////////////////// 
					 
						$sql="
							SELECT  m.* , mt.medictypename_th , mt.medictypename_en  
							FROM medic m 
							LEFT JOIN medictype mt ON (mt.id = m.medictype_id) 
							WHERE 	
								
								m.email = '".$username. "'  
								AND m.password = '".$password."' 
								AND m.deleted = '0' 
								AND m.enable = 'Y' 
								AND m.approve = 'Y' 
							"; 
						$result['sql'] = $sql ;

						$myquery = mysqli_query($conn, $sql);
						$numr = mysqli_num_rows($myquery);
						while($row = mysqli_fetch_assoc($myquery) ) {
							$result[] = $row;
						}

						$result['found'] = $numr;
							
						if($numr>0){
							$result['position'] = '4';
							$result['status'] = 'FOUND'; 
							$data_json	=  json_encode($result);
						}else{
							$result['status'] = 'NOT FOUND';
							$data_json	=  json_encode($result);
						}
							
					}
				}
			}
		}
		////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////


	if( $numr > 0){
		session_start();

			if($result['position'] == '1'){
				$_SESSION['userid'] 	= $result[0]['id'] ;
				$_SESSION['userinfo'] 		= $result[0]['mposition'].$result[0]['titlename']." ".$result[0]['firstname']." " .$result[0]['lastname'];
				$_SESSION['usertype'] 	=   '1' ;
				$_SESSION['usertypename'] 	= "staff";
				$_SESSION['userposition'] 	= $result[0]['positionname'] ;
				$_SESSION['userprofileimg'] 	= '/upload/staff/userprofile/'.$result[0]['profile_image'] ;
			}else if($result['position'] == '2'){

				$titlenamel = "";
				if($result[0]['mposition']){
					$titlenamel .= $result[0]['mposition']." ";
					if($result[0]['positionname_mini'] && $result[0]['positionname_mini']!= "อ." ){
						$titlenamel .=  $result[0]['positionname_mini']." ";
					}
				}else{
					if($result[0]['positionname_mini'] ){
						$titlenamel .=  $result[0]['positionname_mini']." ";
					}
					if($result[0]['titlename']){
						$titlenamel .=  $result[0]['titlename']." " ;
					}
				}

				$_SESSION['userid'] 	= $result[0]['id'] ;
			//	$_SESSION['userinfo'] 		= $result[0]['positionname_mini'].$result[0]['titlename'].$result[0]['firstname']." " .$result[0]['lastname'];
				$_SESSION['userinfo'] 		= $titlenamel .$result[0]['firstname']." " .$result[0]['lastname'];
				$_SESSION['usertype'] 	=   '2' ;
				$_SESSION['usertypename'] 	= "lecturer";
				$_SESSION['userposition'] 	=  "" ;
				$_SESSION['userprofileimg'] 	= "/upload/lecturer/userprofile/".$result[0]['profile_image'] ;
			}else if( $result['position'] == '3' ){
				$_SESSION['userid'] 	= $result[0]['id'] ;
				$_SESSION['collegeyear'] 	= $result[0]['collegeyear'] ;
				//SetGenderTitleNameStudent($result[0]['gender'], $result[0]['titlename_mini'] ,'mini'). " ".$result[0]['firstname']." ".$result[0]['lastname'] ;
				$_SESSION['userinfo'] 		= SetGenderTitleNameStudent($result[0]['gender'], $result[0]['titlename_mini'] ,'mini'). " ".$result[0]['firstname']." ".$result[0]['lastname'] ;
				//	$_SESSION['userinfo'] 		=  $result[0]['titlename_mini']." ".$result[0]['firstname']." " .$result[0]['lastname'];
				$_SESSION['usertype'] 	=   '3' ;

				$_SESSION['usertypename'] 	= "student";
				$_SESSION['student_id'] 	= $result[0]['student_id'];

				$_SESSION['userposition'] 	=  "" ;
				$_SESSION['userprofileimg'] 	= "/upload/student/userprofile/".$result[0]['student_id'].".png"   ;
			}else if($result['position'] == '4'){
				if($result[0]['gender'] =="M"){
					$titlename = "นพ." ;
				} else{
					$titlename = "พญ." ;
				}
				$_SESSION['userid'] 	= $result[0]['id'] ;
				$_SESSION['userinfo'] 		= $titlename. $result[0]['firstname']." " .$result[0]['lastname'];
				$_SESSION['usertype'] 	=   '4' ;
				$_SESSION['usertypename'] 	= "medic";
				$_SESSION['userposition'] 	= $result[0]['medictypename_th'] ;
				$_SESSION['userprofileimg'] 	=  "";
			}


			$_SESSION['LANG']='th' ;
	}else{

	}

	echo  $data_json;


?>
