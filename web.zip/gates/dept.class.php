<?php
header('Access-Control-Allow-Origin: *');
header("Content-type: text/html; charset=utf-8");

class DeptClass extends DuckClass{ 
	////////////////////////////////////////////////////////////////////////////////////////////
	
	public function LoadOfficeByDeptTypeId($deptid){
		if(isset($deptid)){

		 
				$sql="
						SELECT  d.* , dc.department_address_th , dc.department_address_en ,dc.department_tel_th ,dc.department_tel_en ,dc.department_fax_th ,dc.department_fax_en 
						FROM department d
						INNER JOIN department_contacts dc  ON d.id = dc.department_id
						WHERE 
						d.deleted = 0 
						AND d.enable = 'Y'
						AND dc.deleted = 0 
						AND dc.enable = 'Y'
						AND d.department_type ='$deptid'
						ORDER BY d.orderby DESC 
						;
			"; 
				
			
		} else{
			
			$sql="
			SELECT  d.* , dc.department_address_th , dc.department_address_en ,dc.department_tel_th ,dc.department_tel_en ,dc.department_fax_th ,dc.department_fax_en 
			FROM department d
			INNER JOIN department_contacts dc  ON d.id = dc.department_id
			WHERE 
			d.deleted = 0 
			AND d.enable = 'Y'
			AND dc.deleted = 0 
			AND dc.enable = 'Y' 
			ORDER BY d.orderby DESC 
			;
		"; 
		}
		//echo $deptid.$sql;
		$myquery = $this->mysqli->query($sql);
			while($row = $myquery->fetch_assoc() ) {
				$result[] = $row;
			}
			$myquery->free();
		return $result;
	}


	////////////////////////////////////////////////////////////////////////////////////////////

}


?>
