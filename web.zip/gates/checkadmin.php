<?php
	session_start();
	if(  $_SESSION['usertype'] == '2' || $_SESSION['usertype'] == '3'   ){
      
	}else if( $_SESSION['usertype'] == '1'    ){
	
	}else{
		?>
		<script>
          //  alert(' <?php echo $_SESSION['usertype'];?> ') ;
          //  alert(` You don't have permission !  `) ;
			window.location = "/logout.php";
		</script>
		<?php
	}

?>
