<?php 
include "duck.conf.php";
include "prepare_html.php"; 

$menucode = "MAIN" ;
$menucode1 = "MAIN_NEWSMASS" ;

include $pathf."/gates/duck.class.php";
include $pathf."/gates/contents.class.php"; 
include $pathf."/gates/dept.class.php"; 
include $pathf."/gates/func.php";
$langcode=$_SESSION['LANGCODE'];

$clsdept = new DeptClass();
$clscont = new ContentsClass();
?>

  <?php include "prepare_css.php";?>
  <body>
    <?php include "prepare_header.php";?>
    <!-- ############################################################################################################### -->
    <?php include "prepare_bannermain.php";?>
    
    <!-- #####  START CONTENT ##### -->
    <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
    <section id="content-news">
      <div class="container">
        <div class="row">
        
        <div class="container">
            <div class="row">

                

                    <div class="topic_block col-lg-7">
                      <p class="topic_text">ข่าวสื่อมวลชน</p>
                    </div>
                <div class="search_row col-lg-5">
                    <p class="search_text">เลือกหน่วยงาน</p>
                    <select class="search_block">
                        <option>ทุกสำนัก</option>
                        <option>กลุ่มตรวจสอบภายใน</option>
                        <option>กลุ่มพัฒนาระบบบริหาร</option>
                        <option>กองแผนงาน</option>
                        <option>สำนักสื่อสารความเสี่ยงและพัฒนาพฤติกรรมสุขภาพ</option>
                    </select>
                </div>
            </div>
        </div>
        
        <div class="newsmass" id="newsmass" ></div> 
            <!--
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 mt-2">
                        <div class="card">
                            <div class="card-body">
                                <div>
                                    <h5 class="card-title">
                                        <a href="#" class="linknonepink"> 
                                            สคร.1 เชียงใหม่ ประกาศรายชื่อผู้สมัครเข้ารับการเลือกสรร
                                    เพื่อจัดจ้างเป็นพนักงานราชาการ ตำแหน่ง นักวิเคราะห์นโยบายและแผน    สคร.1 เชียงใหม่ ประกาศรายชื่อผู้สมัครเข้ารับการเลือกสรร
                                    เพื่อจัดจ้างเป็นพนักงานราชาการ ตำแหน่ง นักวิเคราะห์นโยบายและแผน 
                                </a> 
                                    </h5>
                                </div>                 
                                <div class="footer-detail">
                                    <div class="row">
                                        <div class=" col-md-2   col-6 time ">
                                        <i class="fa fa-calendar" aria-hidden="true"> </i> 
                                        <span class="ml-0"> 15 March 2019</span>
                                        </div>
                                        <div class=" col-md-2   col-6 view">
                                        <i class="fa fa-eye" aria-hidden="true"> </i> 
                                        <span class="ml-0">20 view</span>
                                        </div>
                                        <div class="col-md-8   col-12 text-right name-depart">
                                        <span class="mr-2"> สำนักสื่อสารความเสี่ยงและพัฒนาพฤติกรรมสุขภาพ </span>  
                                        </div>
                                    </div> 
                                </div> 
                            </div>
                                <hr class="lines linehomenews">
                        </div>  
                    </div>
                </div>
            </div> -->
        
    <div class="container">
        <div class="row">
            <div class="pagination-block">
                <div class="pagination col-lg-6">
                    <a href="#"><i class="fa fa-caret-left" id="fa-pagination" aria-hidden="true"></i></a>
                    <a href="#">1</a>
                    <a class="active" href="#">2</a>
                    <a href="#">3</a>
                    <a href="#">4</a>
                    <a href="#"><i class="fa fa-caret-right" id="fa-pagination" aria-hidden="true"></i></a>
                </div>
            </div>
        </div>
    </div> 

        </div>
      </div>
    </section>  <!--/ section#content-diseasedetail -->
    
    <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
    <!-- #####  END CONTENT ##### -->
  


    <!-- ############################################################################################################### -->
    <?php include "prepare_footer.php";?>
    <?php include "prepare_script.php";?>
    <!-- Optional JavaScript -->
    <script>
    $( document ).ready(function() {
        //dept.LoadNewsmass();
        contents.LoadNewsMass();
    });
    </script>  
  </body>
</html>